This is the loopcore-ai section of LOOP_TOTAL_2025_FINAL.
