This is the docs section of LOOP_TOTAL_2025_FINAL.
