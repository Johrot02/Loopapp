This is the assets section of LOOP_TOTAL_2025_FINAL.
