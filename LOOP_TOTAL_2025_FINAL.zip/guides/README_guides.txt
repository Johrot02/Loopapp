This is the guides section of LOOP_TOTAL_2025_FINAL.
