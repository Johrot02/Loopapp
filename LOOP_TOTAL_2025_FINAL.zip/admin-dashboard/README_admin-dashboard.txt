This is the admin-dashboard section of LOOP_TOTAL_2025_FINAL.
