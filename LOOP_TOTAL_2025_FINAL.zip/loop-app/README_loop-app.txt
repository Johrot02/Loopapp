This is the loop-app section of LOOP_TOTAL_2025_FINAL.
