This is the legal section of LOOP_TOTAL_2025_FINAL.
